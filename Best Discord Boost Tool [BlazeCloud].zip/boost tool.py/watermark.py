class Fore:
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    UNDERLINE = "\033[4m"
    RESET = "\033[0m"
powerboosts = f"""{Fore.GREEN} +   {Fore.CYAN}Telegram: {Fore.MAGENTA}@cloudakos {Fore.CYAN}& {Fore.MAGENTA}@stormwins



                                $$$$$$$\                           $$\           
                                $$  __$$\                          $$ |          
                                $$ |  $$ |$$$$$$\  $$$$$$$\   $$$$$$$ | $$$$$$\  
                                $$$$$$$  |\____$$\ $$  __$$\ $$  __$$ | \____$$\ 
                                $$  ____/ $$$$$$$ |$$ |  $$ |$$ /  $$ | $$$$$$$ |
                                $$ |     $$  __$$ |$$ |  $$ |$$ |  $$ |$$  __$$ |
                                $$ |     \$$$$$$$ |$$ |  $$ |\$$$$$$$ |\$$$$$$$ |
                                \__|      \_______|\__|  \__| \_______| \_______|            

{Fore.RESET}"""
w2 = "pandaboosts.cc"
bname = "@pandaboosts"